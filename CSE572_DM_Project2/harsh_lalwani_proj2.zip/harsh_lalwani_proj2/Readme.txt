Testing the model:
1. Input csv should name- “test.csv”.
2. Should have python 3.7 installed on the machine.
3. Required packages- pickle, statistics, joblib, numpy, pandas, scipy, sklearn
